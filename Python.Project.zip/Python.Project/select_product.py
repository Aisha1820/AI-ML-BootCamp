import BeautyStock
from BeautyStock.Beauty_products import cosmetics_name as td
# import price as p
def beauty_products():
    print("Select cosmetic:")
    print('''1. hair_fall,
    2. face_wash,
    3.face_mask''')
    cosmetics_names=["","hair_fall","face_wash","peeloff_mask"]
    # mls_list=["","25ml","50ml","100ml","250ml","500ml"]
    cosmetics_name=int(input("Enter the selection (1/2/3)"))




    # print("please select ml")
    # print('''1) 25ml
    # 2) 50ml
    # 3) 100ml
    # 4) 250ml
    # 5) 500ml
    # ''')
    # ml=int(input("select ml (1/2/3/4/5)"))
    if cosmetics_name>=0 and  cosmetics_name<=3:
        res=td.shows(cosmetics_names[cosmetics_name])
        j=1
        temp=list(res.keys())
        print(f"select the product")
        print(type(temp),dir(temp))
        for i in temp:
            print(f"{j}) {i}")
            j=j+1
        prd_index=int(input("select product (1/2/3/4) in number format"))-1
        if prd_index>=0 and prd_index<=j:
            print("please select ml")
            print('''1) 25ml
                    2) 50ml
                    3) 100ml
                    4) 250ml
                    5) 500ml
                    ''')
            ml=int(input("select ml (1/2/3/4/5)"))-1
            inp=input("Whether you wanted to know the prices? Say (yes/no)")
            print(f"beauty products \n cosmetic name : {cosmetics_names[cosmetics_name]}")
            print(f" produdct name is {temp[prd_index]}")
            temp=temp[prd_index-1]
            if inp.lower()=="yes":
                print(f"product price is :{res[temp][ml]}")
        else:
            print("non_valid selection please try again later")
    else:
        print(f"please select a valid product")
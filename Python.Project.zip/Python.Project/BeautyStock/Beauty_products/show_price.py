def cosmetic_selected(cosmetics_name):
    if cosmetics_name=="hair_fall":
        print(shows(cosmetics_name))
    elif cosmetics_name=="makeup":
        print(shows(cosmetics_name))
    elif cosmetics_name=="face_wash":
        print(shows(cosmetics_name))
    elif cosmetics_name=="peeloff_mask":
        print(shows(cosmetics_name))
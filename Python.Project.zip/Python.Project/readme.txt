print('''1. hair_fall,
2. makeup,
3. face_wash,
4.face_mask''')

--- hair_fall ---

cosmetics_list=['hair_oil','shampoo','conditioner','hair_mask']
        product_list_dict={'hair_oil':['25ml','50ml','100ml','250ml','500ml'],
                           'shampoo':['25ml','50ml','100ml','250ml','500ml'],
                           'conditioner':['25ml','50ml','100ml','250ml','500ml'],
                           'hair_jell':['25ml','50ml','100ml','250ml','500ml']
                           }


--- makeup ---
 cosmetics_list=['foundation','powder','lipstick','mascara']
        product_list_dict={'foundation':['liquid','dry','powder','jell'],
                           'powder':['white_tone','fruit','sandal_wood','ponds'],
                           'lipstick':['red','pink','purple','blue'],
                           'mascara':['lash','curl','waterproof','fiber']
                           }
        product_price_dict={'foundation':['150RS','220RS','280RS','300RS'],
                       'powder':['260RS','190RS','230RS','390RS'],
                       'lipstick':['120RS','180RS','230RS','80RS'],
                       'mascara':['120RS','230RS','300RS','280RS']
                       }

--- FACE_WASH ---
  cosmetics_list=['fruit','aloevera','neem','teatree']
        product_list_dict={'fruit':['25ml','50ml','100ml','250ml','500ml'],
                           'aloevera':['25ml','50ml','100ml','250ml','500ml'],
                           'neem':['25ml','50ml','100ml','250ml','500ml'],
                           'teatree':['25ml','50ml','100ml','250ml','500ml']
                           }
--- PEELOFF_MASK ---

  cosmetics_list = ['fruit', 'aloevera', 'neem', 'teatree']
        product_list_dict = {'fruit': ['25ml', '50ml', '100ml', '250ml', '500ml'],
                             'aloevera': ['25ml', '50ml', '100ml', '250ml', '500ml'],
                             'neem': ['25ml', '50ml', '100ml', '250ml', '500ml'],
                             'teatree': ['25ml', '50ml', '100ml', '250ml', '500ml']
                             }
